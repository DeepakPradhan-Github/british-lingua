<?php include "breadcrumb.php"; ?>

<!------- body section Start ------>
<section class="">
    <div class="container">
        <div class=" my-5">
        <img src="<?php echo base_url('assets/frontend/default-new/image/Lingua Information Bulletin-1.png')?>" width="100%">
        <img src="<?php echo base_url('assets/frontend/default-new/image/Lingua Information Bulletin-2.png')?>" width="100%">
            
        </div>
    </div>
</section>
 <!------- body section end ------>