<?php include "breadcrumb.php"; ?>

<!------- body section Start ------>
<section class="privacy-policy">
    <div class="container">
        <div class=" my-5">
            <p>
            The information contained in this website is provided by Lingua Multiservices Pvt Ltd and is for general information purposes only. We endeavor to keep the information up to date and correct. We make no representations or warranties of any kind, expressed or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website, the information, products, services, related graphics contained on the website for any purpose. Any reliance you place on such information is therefore strictly at your own risk.            
            </p><br>

            <p>The information contained in this website is provided by Lingua Multiservices Pvt Ltd and is for general information purposes only. We endeavor to keep the information up to date and correct. We make no representations or warranties of any kind, expressed or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website, the information, products, services, related graphics contained on the website for any purpose. Any reliance you place on such information is therefore strictly at your own risk.</p>
            <br>
            <p>The information contained in this website is provided by Lingua Multiservices Pvt Ltd and is for general information purposes only. We endeavor to keep the information up to date and correct. We make no representations or warranties of any kind, expressed or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website, the information, products, services, related graphics contained on the website for any purpose. Any reliance you place on such information is therefore strictly at your own risk.</p>
            <br>
            <p>Every effort is made to keep the website up and running smoothly. However, Lingua Multiservices Pvt Ltd takes no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control.</p>
            <br>
            <p>
            Lingua Multiservices Pvt Ltd <br>
            1/48, Lalita Park, Laxmi Nagar, Delhi- 110092<br>
            Phone: 011-43026787; +919999107254<br>
            E-mail: support@britishlingua.com<br>
            britishlingua.com

            </p>
            
            
            
        </div>
    </div>
</section>
 <!------- body section end ------>